#!/data/data/com.termux/files/usr/bin/bash
RENDER_API_KEY="rnd_XXXXXXXXXXXXXXXXXX"   # your Render API key
RENDER_SERVICE_ID="srv-XXXXXXXXXX"         # your Render service ID
TUNNEL_URL_FILE="$HOME/acetours/tunnel_url.txt"
LAST_URL_FILE="$HOME/acetours/last_deployed_url.txt"
LOG_FILE="$HOME/acetours/update.log"

if [ ! -f "$TUNNEL_URL_FILE" ]; then
    echo "[$(date)] No tunnel URL file found" >> "$LOG_FILE"
    exit 1
fi

CURRENT_URL=$(cat "$TUNNEL_URL_FILE" | tr -d '[:space:]')
if [ -z "$CURRENT_URL" ]; then
    echo "[$(date)] Tunnel URL is empty" >> "$LOG_FILE"
    exit 1
fi

LAST_URL=""
if [ -f "$LAST_URL_FILE" ]; then
    LAST_URL=$(cat "$LAST_URL_FILE" | tr -d '[:space:]')
fi

if [ "$CURRENT_URL" = "$LAST_URL" ]; then
    exit 0
fi

echo "[$(date)] URL changed: $LAST_URL → $CURRENT_URL" >> "$LOG_FILE"

RESPONSE=$(curl -s -w "\n%{http_code}" -X PUT \
    "https://api.render.com/v1/services/${RENDER_SERVICE_ID}/env-vars" \
    -H "Authorization: Bearer ${RENDER_API_KEY}" \
    -H "Content-Type: application/json" \
    -d "[{\"key\": \"SMS_GATEWAY_URL\", \"value\": \"${CURRENT_URL}\"}]")

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)

if [ "$HTTP_CODE" = "200" ]; then
    echo "[$(date)] Render env var updated — next SMS will use new URL" >> "$LOG_FILE"
    echo "$CURRENT_URL" > "$LAST_URL_FILE"
else
    echo "[$(date)] Failed: $HTTP_CODE — $(echo "$RESPONSE" | head -n-1)" >> "$LOG_FILE"
fi
