#!/data/data/com.termux/files/usr/bin/bash
# Install this at: ~/.termux/boot/start.sh
# Requires Termux:Boot from F-Droid
sleep 30
crond
~/acetours/start-tunnel.sh
