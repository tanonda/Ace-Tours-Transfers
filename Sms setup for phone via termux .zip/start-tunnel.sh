#!/data/data/com.termux/files/usr/bin/bash
TUNNEL_URL_FILE="$HOME/acetours/tunnel_url.txt"
pkill -f "localhost.run" 2>/dev/null
sleep 2
ssh -o StrictHostKeyChecking=no \
    -o ServerAliveInterval=30 \
    -o ServerAliveCountMax=3 \
    -R 80:localhost:8080 nokey@localhost.run 2>&1 | \
while IFS= read -r line; do
    echo "$line"
    if echo "$line" | grep -q "localhost.run"; then
        URL=$(echo "$line" | grep -oP 'https://[^\s]+')
        if [ -n "$URL" ]; then
            echo "$URL" > "$TUNNEL_URL_FILE"
            echo "[$(date)] Tunnel URL saved: $URL"
        fi
    fi
done &
echo "Tunnel started in background"
